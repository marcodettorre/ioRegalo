define(function(require) {

  var $ = require("jquery");
  var _ = require("underscore");
  var Backbone = require("backbone");
  var Utils = require("utils");
  var Parse = require("parse");
  var snapper;  
  var StructureView = Backbone.View.extend({

    constructorName: "StructureView",

    id: "main",

    events: {
      "touchend #goToMap": "map",
      "touchend #nav1": "myView",
      "touchend #logOut" : "logOut",
      "touchend #nav2": "map",
      "touchend #bars": "snapjs" 
    },

    initialize: function(options) {
      this.enter = false;
      this.template = Utils.templates.structure;
      this.on("inTheDOM", this.rendered);
      // bind the back event to the goBack function
      //document.getElementById("back").addEventListener("back", this.goBack(), false);
    
      
    },

    rendered: function(e) {
      // if the app is running on an iOS 7 device, then we add the 20px margin for the iOS 7 status bar
      /*if(device.platform == "iOS" && device.version.startsWith("7.")) {
        document.body.style.marginTop = "20px";
        document.body.style.height = "calc(100% - 20px)";
        document.getElementsByTagName("header")[0].style.marginTop = "20px";
      }*/
    },
    snapjs:function(){
      
      snapper = new Snap({
                element: document.getElementById('content'),
                disable: 'right'
            });
      if( snapper.state().state=="left" ){
        snapper.close();
      } 
      else {
        snapper.open('left');
      }
      !function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="https://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");
      
    },
    // generic go-back function
    goBack: function() {
      //window.history.back();
    },

    map: function(event) {
 
        Backbone.history.navigate("map", {
          trigger: true
        });
      
    },

    myView: function(event) {
      Backbone.history.navigate("myview", {
        trigger: true
      });
    },

    searchView: function(event){
      Backbone.history.navigate("searchview", {
        trigger: true
      });
    },


    logOut: function(){
      Backbone.history.navigate("logOut", {
        trigger: true
      });
    },    

    render: function() {
      // load the template
      this.el.innerHTML = this.template({
        "title" : "ioRegalo"
      });
      // cache a reference to the content element
      this.contentElement = this.$el.find('#content')[0];
      return this;
    },

  });

  return StructureView;

});
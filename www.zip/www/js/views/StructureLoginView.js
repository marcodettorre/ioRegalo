define(function(require) {

  var $ = require("jquery");
  var _ = require("underscore");
  var Backbone = require("backbone");
  var Utils = require("utils");
  var Parse = require("parse");
    
  var StructureLoginView = Backbone.View.extend({

    constructorName: "StructureLoginView",

    id: "mainLogin",

    initialize: function(options) {
      // load the precompiled template
      this.template = Utils.templates.structureLogin;
      this.on("inTheDOM", this.rendered);
      // bind the back event to the goBack function
      //document.getElementById("back").addEventListener("back", this.goBack(), false);
    
      
    },

    render: function() {
      // load the template
      this.el.innerHTML = this.template({});
      // cache a reference to the content element
      this.contentElement = this.$el.find('#content')[0];
      return this;
    }, 

  });

  return StructureLoginView;

});
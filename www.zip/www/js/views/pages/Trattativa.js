define(function(require) {
//libs
var $ = require("jquery");
var _ = require("underscore");
var Backbone = require("backbone");
var Utils = require("utils");
var Parse = require("parse");
//pages  
var AddItemTrattativa = require("views/pages/AddTrattativa");


//models
var ItemModel = require("models/ItemModel");


var Trattativa = Utils.Page.extend({

	id: "trattativa",
	className: "i-g page",
	constructorName: "Trattativa",

	model: ItemModel,

	initialize: function() {
		this.showSpinner();
		this.snapper();
		this.item = new ItemModel();
		this.item.on ("ListItemPubblicati", this.appendItems, this );
		this.item.getItemsPubblicati();
		this.template = Utils.templates.trattativa;
	},


	hideSpinner: function() {
		document.getElementById("snap").style.visibility="visible";
		document.getElementById("spinner").style.visibility="hidden";
		document.getElementById("content").style.visibility="visible";
	},

	showSpinner: function() {
		document.getElementById("snap").style.visibility="hidden";
		document.getElementById("spinner").style.visibility="visible";
		document.getElementById("content").style.visibility="hidden";
	},

	snapper:function(){
		snapper = new Snap({
			element: document.getElementById('content'),
			disable: 'right'
		});
		if( snapper.state().state=="left" ){
			snapper.close();
		} 
		!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="https://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");
	},

	appendItems: function(result){
		var result = $.parseJSON(JSON.stringify(result));
		if (result.length == 0){
			$('#listItemTrattativa').append(new AddItemTrattativa({
				model: result[0].descrizione ="nessun item"
			}).render().el);
		}
		else{
		  for (var i = 0; i < result.length; i++) {
			$('#listItemTrattativa').append(new AddItemTrattativa({
				model: result[i]
			}).render().el);
		  }
		}
		this.hideSpinner();

	},



	render: function() {
		document.getElementById("homeicon").style.visibility= "visible";  
		document.getElementsByClassName("h1 title")[0].innerHTML = "<img class=\"logotitolo\" src=\"img/logoIoRegalo.png\"> Trattativa";

		$(this.el).html(this.template());
		return this;
	}
});

return Trattativa;

});
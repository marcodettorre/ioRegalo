define(function(require) {

  var $ = require("jquery");
  var _ = require("underscore");
  var Backbone = require("backbone");
  var Utils = require("utils");
  var Parse = require("parse");
  
  var ItemModel= require("models/ItemModel");


  var PaginaRicercaMappa = Utils.Page.extend({

    constructorName: "PaginaRicercaMappa",

    model: ItemModel,

    initialize: function() {
      this.model.on("ricercaid", this.profilo, this);
      this.model.on("titoloProdotto", this.autoComplete, this);
      this.template = Utils.templates.paginaricercamappa;

    },

    id: "searchmapview",
    className: "i-g page",

    events: {
       "touchend #invioQuery"  : "invioQuery"
    },

    invioQuery : function() {
      this.model.ricerca();

    },

    profilo : function(result) {
      
      this.model.getProfiloAnnuncio(result);
    },

    getListItem : function(){
        this.model.getTitolo();
    },

    

    /*  
    search:function(result){
        this.model.ricerca(result);
    },
    */

    autoComplete: function(titolo){
      $("#autocomplete").autocomplete({      
          lookup: titolo,
          onSelect: function(selected){
            Backbone.history.navigate("/dettagliannuncio/" + selected.data+"/"+ selected.user, {trigger: true});
          }
          });
    },
      
    render: function() {
        document.getElementById("homeicon").style.visibility = "visible";
        $(this.el).html(this.template());
        return this;
      },
    });

  return PaginaRicercaMappa;

});
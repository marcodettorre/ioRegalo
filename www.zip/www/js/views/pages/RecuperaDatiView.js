define(function(require) {

  var $ = require("jquery");
  var _ = require("underscore");
  var Backbone = require("backbone");
  var Utils = require("utils");
  var Parse = require("parse");
  var ErrorModel = require("models/ErrorModel");
  var UserModel = require("models/UserModel");

  var RecuperaDatiView = Utils.Page.extend({

    constructorName: "RecuperaDatiView",

    id: "recuperaDati",

    events: {
      "touchend #recuperaDati": "recuperaDati"
    },

    initialize: function(options) {
        
        this.userModel = new UserModel();
        this.userModel.on("errorRecupero", this.errorRecupero, this );
        this.userModel.on("errorQuery", this.errorQuery, this );
        this.userModel.on("successRecupero", this.successRecupero, this );
        this.template = Utils.templates.recuperaDati;
 
    },

    recuperaDati: function(){

        this.userModel.recuperaDati();
        this.render(); 
        this.showSpinner();    

    },

    errorRecupero: function(){

        this.hideSpinner();

        var message = "▼ Email non presente!";
        var classe = "alert-danger";

        var context = {
            message: message,
            class: classe
        }; 

        $(this.el).html(this.template(context));
        return this;
    },

    errorQuery: function(){

        this.hideSpinner();

        var message = "▼ Query fallita!";
        var classe = "alert-danger";

        var context = {
            message: message,
            class: classe
        }; 

        $(this.el).html(this.template(context));
        return this;
    },

    successRecupero: function(){
        Backbone.history.navigate("loginIoRegalo/1/Password recuperata con successo", {
            trigger: true
        });

    },

    showSpinner: function() {
        document.getElementById("spinner").style.visibility="visible";
        document.getElementById("content").style.visibility="hidden";
        
        
    },

    hideSpinner: function() {
          document.getElementById("spinner").style.visibility="hidden";
          document.getElementById("content").style.visibility="visible";
    },

    render: function() {
                           document.getElementById("backToLogin").style.visibility= "visible";

        $(this.el).html(this.template({}));
        this.hideSpinner();
        return this;

    },

    rendered: function(e) {
      // if the app is running on an iOS 7 device, then we add the 20px margin for the iOS 7 status bar
        if(device.platform == "iOS" && device.version.startsWith("7.")) {

            document.body.style.marginTop = "20px";
            document.body.style.height = "calc(100% - 20px)";
            document.getElementsByTagName("header")[0].style.marginTop = "20px";

        }
    }


  });

  return RecuperaDatiView;

});
define(function(require) {

  var $ = require("jquery");
  var _ = require("underscore");
  var Backbone = require("backbone");
  var Utils = require("utils");
  var Parse = require("parse");
  
  var AddItemTrattativa = Utils.Page.extend({

    constructorName: "AddItemTrattativa",
    id: "addItemTrattativa",
    events: {
          "touchend": "dettagliotrattativa"
        },

    //model: HomePageModel,

    initialize: function() {
          
          var d= new Date(this.model.createdAt);
          this.model.createdAt=d.toLocaleDateString()+ " "+ d.toLocaleTimeString();
          this.template = Utils.templates.rowtrattativa;
    },


    dettagliotrattativa: function () {
          Backbone.history.navigate("dettagliotrattativa/" + this.model.objectId , {trigger: true});    
    },

    render: function() {
          $(this.el).html(this.template(this.model));
          return this;
    }

  });

  return AddItemTrattativa;

});
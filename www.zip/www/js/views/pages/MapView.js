define(function(require) {

  var $ = require("jquery");
  var _ = require("underscore");
  var Backbone = require("backbone");
  var L = require("leaflet");
  var Utils = require("utils");
  var Parse = require("parse");
  var Autocomplete = require("autocomplete");
  var longitudine, latitudine;
  var MapView = Utils.Page.extend({

    constructorName: "MapView",

    id: "map",
    className: "i-g page",
    events: {
      "touchend #invio_ricerca": "addMarkerToMap"
    },

    initialize: function(options) {
      this.snapper();
      this.showSpinner();
      // load the precompiled template
      this.template = Utils.templates.map;
      // when I am in the DOM, I can start adding all the Leaflet stuff
      this.listenTo(this, "inTheDOM", this.addMap);
      

    },
    
    snapper:function(){
		snapper = new Snap({
			element: document.getElementById('content'),
			disable: 'right'
		});
		if( snapper.state().state=="left" ){
			snapper.close();
		} 
		!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="https://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");
    },

    addMarkerMap: function(lati, longi){
      /*navigator.geolocation.getCurrentPosition(function(position) {
        var options = {
          center: new L.LatLng(lati, longi),
          zoom: 12
        };
        
        // create the map
        var  map = L.map('map', options);
          
          

          // say thanks to Leaflet
          map.attributionControl.setPrefix("Leaflet");
          var layer = L.tileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: 'Map data &copy; OpenStreetMap',
            maxZoom: 20
          });
          map.addLayer(layer);
          
          var positionIcon = L.icon({
            iconUrl: './img/seiqui.png',
            iconSize: [40, 55],
          });
          
          var marker=L.marker([position.coords.latitude, position.coords.longitude], {
            icon: positionIcon
          }).bindPopup("<b>Sei qui</b><br>").openPopup();
          map.addLayer(marker);
          var BlueIcon = L.icon({
            iconUrl: './img/Marker_Blue.png',
            iconSize: [55, 55],
          });
          var marker1 = L.marker([lati, longi], {
            icon: BlueIcon
          }).bindPopup("<b>L'oggetto è qui</b><br>").openPopup();
          map.addLayer(marker1);
        }); 
        */
      },

    addMap: function(lati, longi) {
        self = this;
        var planes = [];
        navigator.geolocation.getCurrentPosition(function(position) {
			latitudine=position.coords.latitude;
			longitudine=position.coords.longitude;
          
			if (lati != undefined && longi != undefined){
				planes = [
				["sei qui",latitudine, longitudine],
				["L'oggetto è qui", parseFloat(lati), parseFloat(longi)]
				];  
				var map = L.map('map').setView([lati, longi], 10);
			}
			else {
				planes = [
				["sei qui",latitudine, longitudine],
				];  
			var map = L.map('map').setView([latitudine, longitudine], 10);
           
        }
        mapLink = 
         '<a href="http://openstreetmap.org">OpenStreetMap</a>';
         L.tileLayer(
          'http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; ' + mapLink + ' Contributors',
            maxZoom: 18,
          }).addTo(map);

         for (var i = 0; i < planes.length; i++) {
          marker = new L.marker([planes[i][1],planes[i][2]])
          .bindPopup(planes[i][0])
          .addTo(map);
        }
        self.hideSpinner();
    });
        
      /*
      var options = {
        center: new L.LatLng(latitudine, longitudine),
        zoom: 12
      };
      var map;
      map = L.map('map', options);

          // say thanks to Leaflet
          map.attributionControl.setPrefix("Leaflet");
          // create an icon for showing the user its current location
          var positionIcon = L.icon({
            iconUrl: './img/seiqui.png',
            iconSize: [40, 55],
          });
          var layer = L.tileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: 'Map data &copy; OpenStreetMap',
            maxZoom: 20
          });
          map.addLayer(layer);
          var marker=L.marker([latitudine, longitudine], {
            icon: positionIcon
          }).addTo(map);
          marker.bindPopup("<b>Sei qui</b><br>").openPopup();*/
          
      // get the current location of the user
      
      
    },

    showSpinner: function() {
		document.getElementById("spinner").style.visibility="visible";
		document.getElementById("content").style.visibility="hidden";
		document.getElementById("spinner-off").style.visibility="hidden";
		document.getElementById("snap").style.display="none";
    },

    hideSpinner: function() {
		document.getElementById("spinner").style.visibility="hidden";
		document.getElementById("content").style.visibility="visible";
		document.getElementById("spinner-off").style.visibility="visible";
		document.getElementById("snap").style.display="block";
    },

    render: function() {
      document.getElementById("homeicon").style.visibility= "visible";
      $(this.el).html(this.template({}));
      return this;
    },

  });

return MapView;

});
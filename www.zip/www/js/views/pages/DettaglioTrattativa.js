define(function(require) {
//libs
var $ = require("jquery");
var _ = require("underscore");
var Backbone = require("backbone");
var Utils = require("utils");
var Parse = require("parse");
//pages  
var AddUserTrattativa = require("views/pages/AddUserTrattativa");


//models
var ItemModel = require("models/ItemModel");
var UserModel = require("models/UserModel");

var DettaglioTrattativa = Utils.Page.extend({

  constructorName: "DettaglioTrattativa",

  model: ItemModel,

  initialize: function() {
    this.showSpinner();
    this.snapper();
    this.model.getUserPrenotati();
    this.model.on ("ListDettaglioTrattativa", this.reqListUser, this );
    this.template = Utils.templates.dettagliotrattativa;
  },

  id: "dettagliotrattativa",
  className: "i-g page",
  
  reqListUser:function(result){
    var userModel = new UserModel();
    userModel.getUserPrenotati(result);
    userModel.on ("ListUserTrattativa", this.appendItems, this );
  },

  hideSpinner: function() {
    document.getElementById("snap").style.visibility="visible";
    document.getElementById("spinner").style.visibility="hidden";
    document.getElementById("content").style.visibility="visible";

  },

  showSpinner: function() {
    document.getElementById("snap").style.visibility="hidden";
    document.getElementById("spinner").style.visibility="visible";
    document.getElementById("content").style.visibility="hidden";
    },

    snapper:function(){
    snapper = new Snap({
                element: document.getElementById('content'),
                disable: 'right'
            });
        if( snapper.state().state=="left" ){
            snapper.close();
        } 
        !function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="https://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");
    },

        appendItems: function(result){
          var result = $.parseJSON(JSON.stringify(result));
          if (result.length == 0){

            $('#dettaglioTrattativa').append(new AddUserTrattativa({
                model: result[0].descrizione ="nessun item"
            }).render().el);
          }
          else{
            
            for (var i = 0; i < result.length; i++) {
              $('#dettaglioTrattativa').append(new AddUserTrattativa({
                model: result[i]
              }).render().el);
            }
          }
          this.hideSpinner();
        },



        render: function() {
          document.getElementById("homeicon").style.visibility= "hidden";  
          $(this.el).html(this.template());
          return this;
        }
      });

return DettaglioTrattativa;

});
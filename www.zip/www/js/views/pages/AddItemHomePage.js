define(function(require) {

  var $ = require("jquery");
  var _ = require("underscore");
  var Backbone = require("backbone");
  var Utils = require("utils");
  var Parse = require("parse");
  
  var AddItemHomePage = Utils.Page.extend({

    constructorName: "AddItemHomePage",
    id: "addItemHomePage",
    events: {
          "touchend": "dettagliAnnuncio"
        },

    //model: HomePageModel,

    initialize: function() {
          
          var d= new Date(this.model.createdAt);
          this.model.createdAt=d.toLocaleDateString()+ " "+ d.toLocaleTimeString();
          this.template = Utils.templates.rowhomepage;
    },


    dettagliAnnuncio: function () {

          Backbone.history.navigate("dettagliannuncio/" + this.model.objectId + "/" + this.model.User_Posted_Article.objectId , {trigger: true});    
    },

    render: function() {
          $(this.el).html(this.template(this.model));
          
          return this;
    }

  });

  return AddItemHomePage;

});
define(function(require) {

  var $ = require("jquery");
  var _ = require("underscore");
  var Backbone = require("backbone");
  var Utils = require("utils");
  var Parse = require("parse");
  
  var AddUserTrattativa = Utils.Page.extend({

    constructorName: "AddUserTrattativa",
    id: "addUserTrattativa",
    events: {
          
        },

    //model: HomePageModel,

    initialize: function() {
          
          var d= new Date(this.model.createdAt);
          this.model.createdAt=d.toLocaleDateString()+ " "+ d.toLocaleTimeString();
          this.template = Utils.templates.rowUserTrattativa;
    },


    render: function() {
        document.getElementById("homeicon").style.visibility = "visible";
          $(this.el).html(this.template(this.model));
          return this;
    }

  });

  return AddUserTrattativa;

});
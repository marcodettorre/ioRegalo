define(function(require) {

	var $ = require("jquery");
	var _ = require("underscore");
	var Backbone = require("backbone");
	var Parse = require("parse");
	var Utils = require("utils");
	
	//var pictureSource = navigator.camera.PictureSourceType; 
	//var destinationType = navigator.camera.DestinationType; 

	//models
	var UserModel= require("models/UserModel");
	var self=this;
	var Profilo = Utils.Page.extend({

		constructorName: "profilo",

		//model : UserModel,

		initialize : function() {
			this.showSpinner();
			this.snapper();
			this.model.getProfilo();
			this.model.on("profilo", this.profilo, this);
			this.template = Utils.templates.profilo;
		},

		id : "profilo",
		className : "i-g page",
		
		events : {
			"touchend #edit" : "edit", 
			"touchend #logout" : "logout",
			"touchend #prenotazioni" : "prenotazioni",
			"touchend #ordini" : "ordini",
			"touchend #preferiti" : "preferiti",
			
		},

		hideSpinner: function() {
			document.getElementById("spinner").style.visibility="hidden";
			document.getElementById("content").style.visibility="visible";
		},

		showSpinner: function() {
			document.getElementById("spinner").style.visibility="visible";
			document.getElementById("content").style.visibility="hidden";	     
		},

		snapper:function(){
			snapper = new Snap({
				element: document.getElementById('content'),
				disable: 'right'
			});
			if( snapper.state().state=="left" ){
				snapper.close();
			} 
			
			!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="https://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");
		},

		edit:function(){
			Backbone.history.navigate("edit", {
				trigger : true
			});
		},

		logout : function(event) {
			Backbone.history.navigate("logOut", {
				trigger : true
			});
			
		},
		
		prenotazioni : function(event) {

			Backbone.history.navigate("prenotazioni", {
				trigger : true
			});
		},
		ordini : function(event) {

			Backbone.history.navigate("ordini", {
				trigger : true
			});
		},
		
		profilo : function(result) {
			$(this.el).html(this.template(result));
			this.hideSpinner();

			
			return this;
		},
		
		preferiti : function(){
			Backbone.history.navigate("preferiti", {
				trigger : true
			});
		},
		
		
		render : function() {
			document.getElementById("homeicon").style.visibility = "visible";
			document.getElementsByClassName("h1 title")[0].innerHTML = "<img class=\"logotitolo\" src=\"img/logoIoRegalo.png\"> Profilo";
			$(this.el).html(this.template());
			return this;
			
		},
	});

	return Profilo;

});
define(function(require) {

  var $ = require("jquery");
  var _ = require("underscore");
  var Backbone = require("backbone");
  var Utils = require("utils");
  var AddPosition = require("views/pages/AddPosition");
  var pictureSource = navigator.camera.PictureSourceType;   
  var destinationType = navigator.camera.DestinationType; 
  var ItemModel=require("models/ItemModel");


  var InserisciAnnuncio = Utils.Page.extend({

    constructorName: "InserisciAnnuncio",

    id: "inserisciannuncio",
    className: "i-g page",

    model:ItemModel,

    initialize: function() {
      this.snapper();
      this.posizione();
      this.template = Utils.templates.inserisciannuncio;

    },

    events: {
      "touchend #getPhoto1" : "getPhoto1",
      "touchend #getPhoto2" : "getPhoto2",
      "touchend #getPhoto3" : "getPhoto3",
      "touchend #salva" : "salvataggio"
    },
    salvataggio : function(){    
      this.item = new ItemModel();
      if(this.validate()){    
        this.item.salvaAnnuncio();
      }
      this.item.on("inserimento", this.inserimentoOk, this );
    },

    inserimentoOk : function(){
      navigator.notification.alert(
                 "L'inserimento del tuo annuncio è avvenuto correttamente :)",  // message
                 function(){ },         // callback
                 'Complimenti!!',            // title
                 'Ok'                  // buttonName
                 );
      Backbone.history.navigate("homePage", {trigger: true});
    },

    validate: function(){
      var titolo = document.inserimento.titolo.value;
      var descrizione = document.inserimento.descrizione.value;
      var geo = document.inserimento.latitudine.value;

      if ((titolo== "") || (titolo== "undefined")){
        navigator.notification.alert(
                 "Inserire un titolo.",  // message
                 function(){ },         // callback
                 'Attenzione',            // title
                 'Ok'                  // buttonName
                 );
        document.inserimento.titolo.select();
        return false;
      }
      else {   
        return true 
      }

      if ((descrizione== "") || (descrizione== "undefined")){
        navigator.notification.alert(
                 "Inserire una descrizione.",  // message
                 function(){ },         // callback
                 'Attenzione',            // title
                 'Ok'                  // buttonName
                 );
        document.inserimento.descrizione.select();
        return false;
      }
      else {   
        return true 
      }

      if ((geo== "") || (geo== "undefined")){
        navigator.notification.alert(
                 "Clicca sul pulsante per inserire la tua posizione.",  // message
                 function(){ },         // callback
                 'Attenzione',            // title
                 'Ok'                  // buttonName
                 );
        document.inserimento.descrizione.select();
        return false;
      }
      else {   
        return true 
      }
    },

    posizione:function(){
      navigator.geolocation.getCurrentPosition(this.onSuccess);
    },

    onSuccess:function(position){
      this.model = { 
        latitudine: position.coords.latitude.toString(), 
        longitudine: position.coords.longitude.toString()
      };
      var xmlhttp = new XMLHttpRequest(); 
      var url = "http://maps.googleapis.com/maps/api/geocode/xml?latlng="+this.model.latitudine+","+this.model.longitudine+"&sensor=true";
      xmlhttp.open("GET", url, false);
      xmlhttp.send();
      var xml = xmlhttp.responseXML;
      var indirizzo= xml.getElementsByTagName("formatted_address");
      this.model.geolocation=indirizzo[0].innerHTML;
      $('#posizione').append(new AddPosition({
        model: this.model
      }).render().el);
    },

    snapper:function(){
      snapper = new Snap({
        element: document.getElementById('content'),
        disable: 'right'
      });
      if( snapper.state().state=="left" ){
        snapper.close();
      } 
      else {
        snapper.open('left');
      }
      !function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="https://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");
    },

    getPhoto1: function(e) {
      console.log("getphoto");
      var $img = this.$el.find('img#photo1');
      console.info('Taking Photo');

      navigator.camera.getPicture(
        function(data) {
          $img.show();

          $img.attr('src', "data:image/jpeg;base64," + data);  
          var parseFile = new Parse.File("foto.jpg", {base64:data});

        },
        function(e) {
          console.log("Error getting picture: " + e);
          $('camera-status').innerHTML = e;

        },

        {
          quality: 50, 
          destinationType: navigator.camera.DestinationType.DATA_URL, 
          sourceType : navigator.camera.PictureSourceType.PHOTOLIBRARY}
          );
    },

    getPhoto2: function(e) {
      console.log("getphoto");
      var $img = this.$el.find('img#photo2');
      console.info('Taking Photo');

      navigator.camera.getPicture(
        function(data) {
          $img.show();

          $img.attr('src', "data:image/jpeg;base64," + data);  
          var parseFile = new Parse.File("foto.jpg", {base64:data});

        },
        function(e) {
          console.log("Error getting picture: " + e);
          $('camera-status').innerHTML = e;

        },

        {
          quality: 50, 
          destinationType: navigator.camera.DestinationType.DATA_URL, 
          sourceType : navigator.camera.PictureSourceType.PHOTOLIBRARY}
          );
    },

    getPhoto3: function(e) {
      console.log("getphoto");
      var $img = this.$el.find('img#photo3');
      console.info('Taking Photo');

      navigator.camera.getPicture(
        function(data) {
          $img.show();

          $img.attr('src', "data:image/jpeg;base64," + data);  
          var parseFile = new Parse.File("foto.jpg", {base64:data});

        },
        function(e) {
          console.log("Error getting picture: " + e);
          $('camera-status').innerHTML = e;

        },

        {
          quality: 50, 
          destinationType: navigator.camera.DestinationType.DATA_URL, 
          sourceType : navigator.camera.PictureSourceType.PHOTOLIBRARY}
          );
    },


    onPhotoDataSuccess: function(imageData) {

      var smallImage = document.getElementById('smallImage');
      smallImage.style.display = 'block';
      smallImage.src = "data:image/jpeg;base64," + imageData;

      console.log("imageData" + imageData);
    },

    onPhotoURISuccess: function(imageURI){

      console.log("imageURI  " + imageURI);

      var largeImage = document.getElementById('largeImage');

      largeImage.style.display = 'block';

      largeImage.src = imageURI;


      var parseFile = new Parse.File("mypic.jpg", {base64:imageURI});
        
        var prodotto = new Parse.Object("Cesidio");

        parseFile.save().then(function() {

          prodotto.set("Descrizione", "Joe Smith");
          prodotto.set("Titolo", "prova");
          prodotto.set("Immagine", parseFile );
          prodotto.set("ciao", imageURI);
          prodotto.save();

        }, function(error) {
          console.log("Errore salvataggio parse");
          console.log(error);
        });


        alert("salvataggio");

      },

      capturePhoto: function(events){
        // Retrieve image file location from specified source
        navigator.camera.getPicture(this.onPhotoURISuccess, this.onFail, { quality: 50,
          destinationType: destinationType.DATA_URL,
          sourceType: pictureSource.PHOTOLIBRARY});
        //sourceType: events.target.attributes[1].value }
      },

      capturePhotoEdit: function(){
        // Take picture using device camera, allow edit, and retrieve image as base64-encoded string
        navigator.camera.getPicture(this.onPhotoDataSuccess, this.onFail, { quality: 20, allowEdit: true,
          destinationType: destinationType.DATA_URL });
      },

      onFail: function(message){
        alert('Failed because: ' + message);
      },

      addImage: function(){

        var fileUploadControl = $("#profilePhotoFileUpload")[0];
        var file = fileUploadControl.files[0];


        document.getElementById('provaFile').innerHTML = file;

        var prova = document.getElementById('profilePhotoFileUpload').files;

        var name = document.getElementById('profilePhotoFileUpload').value.substr(12);

        alert("nome vale: " + $('input[type=file]').val() );


        if (fileUploadControl.files.length > 0) {

          var parseFile = new Parse.File(name, file);

          parseFile.save();

          var prodotto = new Parse.Object("Cesidio");
          prodotto.set("Descrizione", "Joe Smith");
          prodotto.set("Titolo", "prova");
          prodotto.set("Immagine", parseFile );
          prodotto.save();


        }

        this.render();

      },

      render: function() {
        document.getElementById("homeicon").style.visibility = "visible";
        document.getElementsByClassName("h1 title")[0].innerHTML = "<img class=\"logotitolo\" src=\"img/logoIoRegalo.png\"> Inserimento";
        $(this.el).html(this.template());
        return this;
      }
    });

return InserisciAnnuncio;

});
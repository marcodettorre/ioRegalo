define(function(require) {
	//libs
  var $ = require("jquery");
  var _ = require("underscore");
  var Utils = require("utils");
  var Backbone=require("backbone");
  var Parse=require("parse");
  
  //models
  var UserModel= require("models/UserModel");


  
  var Registrazione = Backbone.View.extend({

    constructorName: "Registrazione",

    id: "regitrazione",

    events: {
      "touchend #inviaregistrazione": "registrazione"
    },

    initialize: function(options) {
      // load the precompiled template
    	
    	this.template = Utils.templates.registrazione;

    },

    render: function() {
                                 document.getElementById("backToLogin").style.visibility= "visible";

      this.el.innerHTML = this.template({});
      this.contentElement = this.$el.find('#content')[0];
      return this;
    },


    // generic go-back function
    goBack: function() {
      //window.history.back();
    },

    goToStructure: function(){
    	
    	Backbone.history.navigate("showstructure", {
            trigger: true
        });
    },

    registrazione: function(event) {
    	

    	if(this.validate()){
    		
    		this.model.registrazione();
    	} 
    	this.model.on("registrato", this.goToStructure, this);
    },
   
    validate: function(){
    	var password = document.formregistrazione.password.value;
    	var conferma = document.formregistrazione.conferma.value;
    	var email = document.formregistrazione.email.value;
    	var email_reg_exp = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-]{2,})+\.)+([a-zA-Z0-9]{2,})+$/;
    	if (password != conferma) {
    		  // alert("La password confermata � diversa da quella scelta, controllare.");
    		   navigator.notification.alert(
  	    		     'La password confermata  diversa da quella scelta, controllare.',  // message
  	    		     function(){ },         // callback
  	    		     'Attenzione',            // title
  	    		     'Ok'                  // buttonName
  	    		 );
    		   document.formregistrazione.conferma.value = "";
    		   document.formregistrazione.conferma.focus();
    		   return false;}
    	else if (!email_reg_exp.test(email) || (email == "") || (email == "undefined")) {
    			   //alert("Inserire un indirizzo email corretto.");
    		 navigator.notification.alert(
  	    		     'Inserire un indirizzo email corretto.',  // message
  	    		     function(){ },         // callback
  	    		     'Attenzione',            // title
  	    		     'Ok'                  // buttonName
  	    		 );
    			   document.formregistrazione.email.select();
    			   return false;
    			}
    	else {   return true }
    }
    
    
  });

  return Registrazione;

});
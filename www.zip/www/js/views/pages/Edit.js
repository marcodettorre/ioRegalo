define(function(require) {

	var $ = require("jquery");
	var _ = require("underscore");
	var Backbone = require("backbone");
	var Parse = require("parse");
	var Utils = require("utils");
	
	var pictureSource = navigator.camera.PictureSourceType; 
	var destinationType = navigator.camera.DestinationType; 
	
	var Edit = Utils.Page.extend({

	    constructorName: "Edit",

		//model : UserModel,

		initialize : function() {
			this.showSpinner();
		    this.model.getProfilo();
		    this.model.on("profilo", this.edit, this);
			this.template = Utils.templates.edit;
		},

		id : "edit",
		className : "i-g page",
	
		events : {

		    "touchend #getPhoto1": "getPhoto",
		    "touchend #save" : "savedata"
		 
		},
		
		hideSpinner: function() {
        document.getElementById("spinner").style.visibility="hidden";
        document.getElementById("content").style.visibility="visible";
   		 },

	    showSpinner: function() {
	        document.getElementById("spinner").style.visibility="visible";
	        document.getElementById("content").style.visibility="hidden";
	     
    	},

		edit : function(result) {
			  	$(this.el).html(this.template(result));
			  	this.hideSpinner();
				return this;
		},

		savedata:function(){
				if(this.validate){
				this.model.saveData();
				}
				this.model.on("editok", this.change, this);
		},

		change:function(result){
				Backbone.history.navigate("profiloutente", {
				trigger : true
				});

		},

		validate: function(){
		    	var password = document.editprofile.password.value;
		    	var conferma = document.editprofile.conferma.value;
		    	var email = document.editprofile.email.value;
		    	var email_reg_exp = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-]{2,})+\.)+([a-zA-Z0-9]{2,})+$/;
		    	if (password != conferma) {
		    		  
		    		   navigator.notification.alert(
		  	    		     'La password confermata  diversa da quella scelta, controllare.',  // message
		  	    		     function(){ },         // callback
		  	    		     'Attenzione',            // title
		  	    		     'Ok'                  // buttonName
		  	    		 );
		    		   document.editprofile.conferma.value = "";
		    		   document.editprofile.conferma.focus();
		    		   return false;}
		    	else if (!email_reg_exp.test(email) || (email == "") || (email == "undefined")) {
		    			   
		    		 navigator.notification.alert(
		  	    		     'Inserire un indirizzo email corretto.',  // message
		  	    		     function(){ },         // callback
		  	    		     'Attenzione',            // title
		  	    		     'Ok'                  // buttonName
		  	    		 );
		    			   document.editprofile.email.select();
		    			   return false;
		    			}
		    	else {   return true }
		    	},

		getPhoto: function(e) {
				console.log("getphoto");
		        var $img = this.$el.find('img#photo');
		        console.info('Taking Photo');
		       
		        navigator.camera.getPicture(
		            function(data) {
		                $img.show();
		                
		                $img.attr('src', "data:image/jpeg;base64," + data);  
		                var parseFile = new Parse.File("mypic.jpg", {base64:data});
		    	          
	    	            var user = Parse.User.current();
	    	         
	    	                  user.set("foto", parseFile );
	    	                  user.save(null, {
	    	      				success : function(user) {	
	    	    				},
	    	    				error : function(user, error) {
	    	    					alert('Failed to create new object, with error code: '
	    	    							+ error.message);
	    	    				}
	    	    			});	    
		            },
		            function(e) {
		                console.log("Error getting picture: " + e);
		                $('camera-status').innerHTML = e;
		               
		            },
		          
		            {
		            	quality: 50, 
		            	destinationType: navigator.camera.DestinationType.DATA_URL, 
		            	sourceType : navigator.camera.PictureSourceType.PHOTOLIBRARY}
		        );
	    },

	    render : function() {
		document.getElementById("homeicon").style.visibility = "visible";
		$(this.el).html(this.template());

			return this;
		
		},
	});

	return Edit;

});
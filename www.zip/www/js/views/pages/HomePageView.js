define(function(require) {
//libs
var $ = require("jquery");
var _ = require("underscore");
var Backbone = require("backbone");
var Utils = require("utils");
var Parse = require("parse");
//pages  
var AddItemHomePage = require("views/pages/AddItemHomePage");


//models
var ItemModel=require("models/ItemModel");

var HomePageView = Utils.Page.extend({

  constructorName: "HomePageView",

  model: ItemModel,

  initialize: function() {
    this.showSpinner();
    this.snapper();
    this.item = new ItemModel();
    this.item.on ("ListItem", this.appendItems, this );
    this.item.getItems();
    this.template = Utils.templates.homepage;
  },

  id: "homepage",
  className: "i-g page",

  events: {
  },

  hideSpinner: function() {
    document.getElementById("snap").style.visibility="visible";
    document.getElementById("spinner").style.visibility="hidden";
    document.getElementById("content").style.visibility="visible";
    document.getElementById("snap").style.display="block";
  },

  showSpinner: function() {

    document.getElementById("spinner").style.visibility="visible";
    document.getElementById("content").style.visibility="hidden";
    document.getElementById("snap").style.display="none";
    var opts = {
            lines: 10, // The number of lines to draw
            length: 20, // The length of each line
            width: 8, // The line thickness
            radius: 15, // The radius of the inner circle
            corners: 1, // Corner roundness (0..1)
            rotate: 0, // The rotation offset
            direction: 1, // 1: clockwise, -1: counterclockwise
            color: '#d65900', // #rgb or #rrggbb or array of colors
            speed: 1, // Rounds per second
            trail: 60, // Afterglow percentage
            shadow: false, // Whether to render a shadow
            hwaccel: false, // Whether to use hardware acceleration
            className: 'spinner', // The CSS class to assign to the spinner
            zIndex: 2e9, // The z-index (defaults to 2000000000)
            top: '45%', // Top position relative to parent
            left: '50%' // Left position relative to parent
          };	


          var target = document.getElementById('spinner');
          var spinner = new Spinner(opts).spin(target);
        },
        
        snapper:function(){
          
          snapper = new Snap({
            element: document.getElementById('content'),
            disable: 'right'
          });
          if( snapper.state().state=="left" ){
           snapper.close();
         } 

         !function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="https://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");
       },

       appendItems: function(result){

        var result = $.parseJSON(JSON.stringify(result));
        for (var i = 0; i < result.length; i++) {
          $('#listItemHomePage').append(new AddItemHomePage({
            model: result[i]
          }).render().el);
        }
        this.hideSpinner();

      },

      

      render: function() {
        document.getElementById("homeicon").style.visibility= "hidden";
        document.getElementById("snap").style.visibility= "visible";
        document.getElementById("bars").style.visibility= "visible";
        document.getElementById("backToLogin").style.visibility= "hidden";
        document.getElementById("search").style.visibility= "visible";
        document.getElementsByClassName("h1 title")[0].innerHTML = "<img class=\"logotitolo\" src=\"img/logoIoRegalo.png\"> ioRegalo";
        $(this.el).html(this.template());
        return this;
      }
    });

return HomePageView;

});
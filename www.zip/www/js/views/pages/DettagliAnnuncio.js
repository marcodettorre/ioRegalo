define(function(require) {
	//libs
	var $ = require("jquery");
	var _ = require("underscore");
	var Backbone = require("backbone");
	var Utils = require("utils");
	var Parse = require("parse");
	//models
	var UserModel = require("models/UserModel");
	var DettaglioModel= require("models/ItemModel");
	var ItemModel = require("models/ItemModel");
	var ItemCollection = require("collections/ItemCollection");

	var DettagliAnnuncio = Utils.Page.extend({
		constructorName: "DettagliAnnuncio",

		model:DettaglioModel,

		events : {
			"touchend #prenotazione" : "incrementaPrenotazione",
			"touchend #position" : "posizione",
			"touchend #contatta" : "contatta"
		},

		initialize: function() {
			this.showSpinner();
			this.model.on ("dettaglio", this.showDettaglio, this );
			this.template = Utils.templates.dettagliannuncio;  
		},

		id: "dettagliannuncio",

		showSpinner: function() {
			document.getElementById("spinner").style.visibility="visible";
			document.getElementById("content").style.visibility="hidden";
			document.getElementById("snap").style.display="none";


		},

		hideSpinner: function() {
			document.getElementById("snap").style.visibility="visible";
			document.getElementById("spinner").style.visibility="hidden";
			document.getElementById("content").style.visibility="visible";
			document.getElementById("snap").style.display="block";
			var swiper = new Swiper('.swiper-container', {
				pagination: '.swiper-pagination',
				
				paginationClickable: true,
				
			});
		},


		showDettaglio:function(results){ 

			var self=this;
			var result = $.parseJSON(JSON.stringify(results));
			var dataApp = (result[0].createdAt).split('T');
			var oraApp = (dataApp[1]).split(".");
			var data = dataApp[0];
			var ora = oraApp[0];
			this.model.set({
				Descrizione: result[0].Descrizione,
				Prenotazioni: result[0].Prenotazioni,
				Immagine: result[0].Immagine,
				Immagine1: result[0].Immagine1,
				Immagine2: result[0].Immagine2,
				Posizione : result[0].Posizione,
				Titolo: result[0].Titolo,
				User_Posted_Article : result[0].User_Posted_Article,
				createdAt : result[0].createdAt,
				objectId : result[0].objectId,
				data: data,
				ora: ora
			});

			var usermodel = new UserModel();
			usermodel.on("userdettaglio", self.viewUser,self);
			usermodel.userAnnuncio();
		},



		viewUser: function(results) { 
			//  var spinner = new Spinner().spin()target.appendChild(spinner.el);    
			var result = $.parseJSON(JSON.stringify(results));
			this.model.set({
				telefono : result[0].telefono,
				email: result[0].email,
				username: result[0].username,
				iscrittoIl: result[0].createdAt
			}); 
			$(this.el).html(this.template(this.model.attributes));
			this.hideSpinner();
			return this;
			
		},
		

		incrementaPrenotazione:function(){
			var itemModel = new ItemModel();
			itemModel.on("prenotazioneaggiornata",this.aggiornaPrenotazione,this);
			itemModel.incrementaPrenotazione(this.model.attributes.User_Posted_Article.objectId);
		},

		aggiornaPrenotazione:function(results){
			if (results == "mioarticolo"){
				navigator.notification.alert(
  	    		     'Articolo pubblicato da te, non puoi prenotarti.',  // message
  	    		     function(){ },         // callback
  	    		     'Prenotazione',            // title
  	    		     'Ok'                  // buttonName
  	    		     );
			}
			else if (results == "prenotato" ){
				navigator.notification.alert(
  	    		     'Ti sei già prenotato.',  // message
  	    		     function(){ },         // callback
  	    		     'Prenotazione',            // title
  	    		     'Ok'                  // buttonName
  	    		     );
			}

			else {
			navigator.notification.alert(
  	    		     'Prenotazione effettuata con successo.',  // message
  	    		     function(){ },         // callback
  	    		     'Prenotazione',            // title
  	    		     'Ok'                  // buttonName
  	    		     );
			}
		},

		posizione:function(){
			Backbone.history.navigate("mapitems/" + this.model.attributes.Posizione.latitude + "/" + this.model.attributes.Posizione.longitude, {
				trigger: true
			});
		},
		
		

		reqDettaglio:function(){
			this.model.dettaglioAnnuncio();
		},

		render: function() {
			document.getElementById("homeicon").style.visibility = "visible";
			$(this.el).html(this.template(this.model.toJSON()));
			return this;
		}   

		
	});

	return DettagliAnnuncio;

});
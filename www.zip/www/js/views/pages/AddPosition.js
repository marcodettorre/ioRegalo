define(function(require) {

  var $ = require("jquery");
  var _ = require("underscore");
  var Backbone = require("backbone");
  var Utils = require("utils");
  var Parse = require("parse");
  

  var AddPosition = Utils.Page.extend({

    constructorName: "AddPosition",
    
    initialize: function() {
      this.template = Utils.templates.addposition;

    },
    

    render: function() {
      $(this.el).html(this.template(this.model));
      return this;
    }



  });

  return AddPosition;

});
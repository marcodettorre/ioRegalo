define(function(require) {

	var $ = require("jquery");
	var _ = require("underscore");
	var Backbone = require("backbone");
	var ItemModel = require("models/ItemModel");
	var Parse = require("parse");

	var ItemCollection = Backbone.Collection.extend({
		constructorName: "ItemCollection",
		model: ItemModel,
/*
	itemscollection:function(){
		var item = new ItemModel();
		model.dettaglioAnnuncio();
		model.on("dettaglio", this.showDettaglio, this );
	},

	showDettaglio:function(results){ 
        var result = $.parseJSON(JSON.stringify(results));
        	//for (var i = 0; i < result.length; i++) {
          
            	model: result[i],
            	console.log(result[i]);
               
          //$(self.el).html(self.template(result[0]));
          	//}
    },
*/

	});

	return ItemCollection;

});
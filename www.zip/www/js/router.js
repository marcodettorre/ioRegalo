define(function(require) {
//library
var $ = require("jquery");
var _ = require("underscore");
var Backbone = require("backbone");
var Parse = require("parse");
var Autocomplete = require("autocomplete");
  //models
  var ErrorModel = require("models/ErrorModel");
  var ItemModel = require("models/ItemModel");
  var UserModel = require("models/UserModel");
  //views
  var Edit = require("views/pages/Edit");
  var Registrazione = require("views/pages/Registrazione");
  var Profilo = require("views/pages/Profilo");
  var StructureView = require("views/StructureView");
  var MapView = require("views/pages/MapView");
  var PaginaRicercaMappa = require("views/pages/PaginaRicercaMappa");
  var InserisciAnnuncio = require("views/pages/InserisciAnnuncio");
  var LoginView = require("views/pages/LoginView");
  var DettagliAnnuncio = require("views/pages/DettagliAnnuncio");
  var LoginFacebookView = require("views/pages/LoginFacebookView");
  var LoginIoRegaloView = require("views/pages/LoginIoRegaloView");
  var HomePageView = require("views/pages/HomePageView");
  var RecuperaDatiView = require("views/pages/RecuperaDatiView");
  var Prenotazioni = require("views/pages/Prenotazioni");
  var Trattativa = require("views/pages/Trattativa");
  var DettaglioTrattativa = require("views/pages/DettaglioTrattativa");

  

  var AppRouter = Backbone.Router.extend({

    constructorName: "AppRouter",

    routes: {
      // the default is the structure view
      "": "showStructure",
      "showstructure" : "showStructure",
      "loginFacebook": "loginFacebook",
      "loginIoRegalo" : "loginIoRegalo", 
      "logOut" : "logOut",
      "loginIoRegalo/:urlNumber/:message" : "loginIoRegalo",
      "myview": "myView",
      "map": "map",
      "mapitems/:lati/:longi" : "mapItems",
      "dettagliannuncio/:id/:userid" : "dettagliAnnuncio",
      "homePage" : "homePage",
      "login": "logIn",
      "paginaricercamappa":"search",
      "inserisciannuncio" : "inserisciAnnuncio",
      "profiloutente" : "profiloUtente",
      "recuperaDati" : "recuperaDati",
      "edit" : "edit",
      "registrazione" : "registrazione",
      "prenotazioni" : "prenotazione",
      "trattativa" : "trattativa",
      "dettagliotrattativa/:objectId" : "dettagliotrattativa",
      "rimuoviRegalo" : "rimuoviRegalo"
    },

    firstView: "login",
    secondView: "homePage",

    initialize: function(options) {
      this.currentView = undefined;
    },

    registrazione:function(){
      var modello = new UserModel();
      var page = new Registrazione({
        model: modello    
      });   
      this.changePage(page);
    },

    edit:function(){
      var modello = new UserModel();
      var page = new Edit({
        model: modello    
      });   
      this.changePage(page);
    },

    profiloUtente:function(){
      var modello = new UserModel();
      var page = new Profilo({
        model: modello    
      });   
      this.changePage(page);
    },


    inserisciAnnuncio: function(){
      var page = new InserisciAnnuncio(); 
      this.changePage(page);
      
    },

    search: function(){
      var item = new ItemModel();
      var page = new PaginaRicercaMappa({
        model: item
      }); 
      page.getListItem();
      this.changePage(page);


    },

    dettagliAnnuncio: function(id,userid){
      var self=this;
      var articolo = new ItemModel();
      articolo.setId(id);
      var modello = new UserModel();
      modello.setIdPosted(userid);
      var page = new DettagliAnnuncio({
        model: articolo
      });
      page.reqDettaglio();
      this.changePage(page);
    },

    
    loginFacebook: function(){

      var page = new LoginFacebookView();
      this.changePage(page);

    },

    loginIoRegalo: function(urlNumber,message){

        // se ricevo in input un codice d'errore chiamalo ma showMessage dell'errore
        if(urlNumber){

          if(urlNumber == 0) {
            message = "▼ " + message;
            var classe = "alert-danger";
          }    
          else {
            message = "✔ " + message;
            var classe = "alert-success";
          }
          
          var page = new LoginIoRegaloView();
          this.changePage(page);
          page.showMessage(message,classe);
          
        } else {
          var page = new LoginIoRegaloView();
          this.changePage(page);

        }
        
      },

      logIn: function(){
        
        var page = new LoginView();
        this.changePage(page); 
      },

      logOut: function() {
        localStorage.clear();
        this.showStructure();
        
      },

      recuperaDati: function(){

        var page = new RecuperaDatiView();
        this.changePage(page);
        
      },


      homePage: function(){
        var page = new HomePageView();
        this.changePage(page);
      },

      map: function() {      
        var page = new MapView();
        this.changePage(page);
      },

      mapItems:function(lati,longi){
        var page = new MapView();
        page.addMap(lati,longi);
        this.changePage(page);
      },

      prenotazione: function(){
        var page = new Prenotazioni();
        this.changePage(page);

      },

      trattativa : function(){
        var page = new Trattativa();
        this.changePage(page);
      },

      dettagliotrattativa: function(objectId){
        var item = new ItemModel();
        item.setObjectId(objectId);
        var page = new DettaglioTrattativa({
          model: item
        });
        this.changePage(page);
      },

    // load the structure view
    showStructure: function() {
      if (!this.structureView) {
        this.structureView = new StructureView();
        // put the el element of the structure view into the DOM
        document.body.appendChild(this.structureView.render().el);
        this.structureView.trigger("inTheDOM");
      }
      if(!localStorage.getItem('login')){
        this.navigate(this.firstView, {trigger: true});
      }
      else{
        this.navigate(this.secondView, {trigger: true});
      }
    },
    rimuoviRegalo:function(){
      alert("sono qui");
    }

  });

return AppRouter;

});
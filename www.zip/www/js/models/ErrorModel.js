define(function(require) {

	var $ = require("jquery");
	var _ = require("underscore");
	var Backbone = require("backbone");
	var Parse = require("parse");


	var ErrorModel = Parse.Object.extend({
		constructorName: "ErrorModel",
		className: "",
		defaults: {
			"url": undefined,
		    "message": undefined
		}
	});

	return ErrorModel;
});
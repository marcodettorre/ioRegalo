define(function(require) {

 var $ = require("jquery");
 var _ = require("underscore");
 var Backbone = require("backbone");
 var Parse = require("parse");
 var Prodotti = Parse.Object.extend("Prodotti");
 var Prenotazione = Parse.Object.extend("Prenotazione");

 var ItemModel = Backbone.Model.extend({
  constructorName: "ItemModel",
  idArticoloPublic: "",
  objectId:"",


  salvaAnnuncio:function(){
    var self = this;
    var prodotti = new Prodotti();
    var geopoint = new Parse.GeoPoint({
      latitude: parseFloat(document.inserimento.latitudine.value),
      longitude: parseFloat(document.inserimento.longitudine.value)
    });  

    prodotti.set("Descrizione", document.inserimento.descrizione.value);
    prodotti.set("Immagine", document.inserimento.image1);
    prodotti.set("Immagine1", document.inserimento.image2);
    prodotti.set("Immagine2", document.inserimento.image3);
    prodotti.set("Posizione",geopoint);         
    prodotti.set("Prenotazioni",0);           
    prodotti.set("Titolo", document.inserimento.titolo.value);
    prodotti.set("User_Posted_Article",{
      __type : "Pointer",
      className : "User",
      objectId : localStorage.getItem('id')
    });
    prodotti.save({
      success : function(results){
        var result = $.parseJSON(JSON.stringify(results));
        self.trigger("inserimento", result[0]);
      },
      error:function(error){
        console.log("Error: " + error.code + " " + error.message);
        alert("Query fallita");
      }
    });

  },

  getProfiloAnnuncio : function() {
    var self = this;
    var query = new Parse.Query(Prodotti);
    query.equalTo("objectId", idArticoloPublic);

    query.find({
      success : function(results) {

        var result = $.parseJSON(JSON.stringify(results));

        self.trigger("profiloAnnuncio", result[0]);

      },
      error : function() {
      }
    });

  },




  getTitolo : function() {
    var self = this;
    var query = new Parse.Query(Prodotti);
    title= new Array();
              //query.select("Titolo");
              query.find({
                success : function(results) {
                  var result = $.parseJSON(JSON.stringify(results));
                  for (var i = 0; i < result.length; i++) {
                    title[i] ={"value": result[i].Titolo, "data": result[i].objectId, "user": result[i].User_Posted_Article.objectId };
                  }
                  self.trigger("titoloProdotto", title);
                },

                error : function(error) {
                  alert("Error: " + error.code + " " + error.message);
                  alert("Query fallita");
                }
              });
            },

            ricerca:function(){
              var self = this;
              var query = new Parse.Query(Prodotti);
              var prendiInput= document.searchform.ricerca.value;
              query.equalTo("Titolo", document.searchform.ricerca.value);
              query.find().then(function(results){
                var queryArray = new Array();
                for(i in results){
                  var obj = results[i];
                  var id = obj.id;
                  self.trigger("ricercaid", id);
                }
              });

            },

            getItems:function(){
             var self = this;
             var query = new Parse.Query(Prodotti);

             query.find({

              success: function(results) {       
                var result= $.parseJSON(JSON.stringify(results));
                self.trigger("ListItem", result);
              },

              error: function(error) {
                alert("Error: " + error.code + " " + error.message);
                alert("Query fallita");
              }
            });
           },

           getUserPrenotati : function(){
            var self = this;
            var prenotazione = new Parse.Query(Prenotazione);
            prenotazione.equalTo("iDArticle",{              
              __type : "Pointer",
              className : "Prodotti",
              objectId: objectId
            });
            prenotazione.find({
              success:function(results){
               var result= $.parseJSON(JSON.stringify(results));
               self.trigger("ListDettaglioTrattativa", result);
               
             },
             error:function(error){
              alert("Error: " + error.code + " " + error.message);
              alert("Query fallita");
            }

          });
          },  


          getItemsPubblicati:function(){
            var arrayResult = [];
            var self = this;
            var prodotti = new Parse.Query(Prodotti);
            prodotti.equalTo("User_Posted_Article",{              
              __type : "Pointer",
              className : "_User",
              objectId: localStorage.getItem('id')
            });
            prodotti.find({
              success:function(results){
                
                var result= $.parseJSON(JSON.stringify(results));
                self.trigger("ListItemPubblicati", result);
                
              },
              error:function(error){
                alert("Error: " + error.code + " " + error.message);
                alert("Query fallita");
              }

            });
          },

          getItemsPrenotazioni:function(){
            var arrayResult = [];
            var self = this;
            var prenotazioni = new Parse.Query(Prenotazione);
            prenotazioni.equalTo("idUser",{              
              __type : "Pointer",
              className : "_User",
              objectId: localStorage.getItem('id')
            });
            prenotazioni.find({
              success: function(results){
                for (var i = 0; i < results.length; i++) {
                  var prodotti = new Parse.Query(Prodotti);
                  prodotti.equalTo("objectId", results[i].attributes.iDArticle.id);
                  prodotti.find({
                    success: function(results) {  
                      var result= $.parseJSON(JSON.stringify(results));
                      arrayResult[i] = arrayResult.push(result);
                      self.trigger("ListItemPrenotazioni", result);
                    },
                    error: function(error) {
                      alert("Error: " + error.code + " " + error.message);
                      alert("Query fallita");
                    }
                  });
                  
                }
                
              },
              error : function(results){
                alert("Error: " + error.code + " " + error.message);
                alert("Query fallita");
              }

            });

            
          },

          dettaglioAnnuncio:function(){
            var self=this;
            var query = new Parse.Query(Prodotti);
            query.equalTo("objectId",idArticoloPublic);
            query.find({
              success: function(results) {         
                var result= $.parseJSON(JSON.stringify(results));
                self.trigger("dettaglio", result);  
              },

              error: function(error) {
                alert("Error: " + error.code + " " + error.message);
                alert("Query fallita");
              }
            });

          },



          queryPrenota1:function(){  
            var queryPrenota = new Parse.Query(Prenotazione);
            queryPrenota.equalTo("iDArticle",{
              __type : "Pointer",
              className : "Prodotti",
              objectId : idArticoloPublic
            });
            queryPrenota.find({
              success:function(results){

                return results;
              },
              error:function(error){
                ("Query fallita");

              }
            });
          },  

          queryPrenota2:function(){
            var queryPrenota = new Parse.Query(Prenotazione);
            queryPrenota.equalTo("idUser",{              
              __type : "Pointer",
              className : "User",
              objectId: localStorage.getItem('username')
            });
            queryPrenota.find({
              success:function(results){                 
               return results;
             },
             error:function(error){
              alert("Query fallita");
            }
          });
          },


          incrementaPrenotazione : function() {
            var self=this;
            var prenota = new Prenotazione();
            var queryPrenota = new Parse.Query(Prenotazione);
            queryPrenota.equalTo("idUser",{              
              __type : "Pointer",
              className : "_User",
              objectId: localStorage.getItem('id')
            });
            queryPrenota.equalTo("iDArticle",{
              __type : "Pointer",
              className : "Prodotti",
              objectId : idArticoloPublic
            });
            queryPrenota.find({
              success:function(results){
                console.log(results);
                var result= $.parseJSON(JSON.stringify(results));
                if(results.length>=1){
                  self.trigger("prenotazioneaggiornata","prenotato");                  
                }
                /*else if(result[0].idUser.objectId == localStorage.getItem('id')){
                  self.trigger("prenotazioneaggiornata","mioarticolo");
                }*/
                
                else{
                  prenota.set("iDArticle",  {
                    __type : "Pointer",
                    className : "Prodotti",
                    objectId : idArticoloPublic
                  });            
                  prenota.set("idUser",     {              
                    __type : "Pointer",
                    className : "_User",
                    objectId:localStorage.getItem('id')
                  });
                  prenota.save(null, {
                    success : function(prenotation){
                      var result = $.parseJSON(JSON.stringify(prenotation));
                      self.trigger("prenotazioneaggiornata",prenotation);
                    },
                    error:function(){
                      alert("Error: " + error.code + " " + error.message);
                      alert("Query fallita");
                    }
                  });
                  var query = new Parse.Query(Prodotti);
                  query.equalTo("objectId",idArticoloPublic);
                  query.find({
                    success:function(results){
                      var result = results[0];
                      result.increment("Prenotazioni");
                      result.save();
                    },
                    error:function(){
                      alert("Query fallita");
                    }
                  });
                }
              },
              error:function(error){
                alert("Query fallita");
              }
            });
          },


          getPosition : function(){
            var self=this;
            var query = new Parse.Query(Prodotti);
            query.equalTo("objectId",idArticoloPublic);
            query.find({
              success:function(results){
                var result= $.parseJSON(JSON.stringify(results));
                self.trigger("position",result[0].Posizione);
              },
              error:function(){
                alert("Error: " + error.code + " " + error.message);
                alert("Query fallita");
              }
            });

          },

          setId : function(id) {

            idArticoloPublic = id;
          }, 

          setObjectId : function(id) {

            objectId = id;
          }, 

        });

return ItemModel;
});
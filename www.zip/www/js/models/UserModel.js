define(function(require) {
	
	var $ = require("jquery");
	var _ = require("underscore");
	var Backbone = require("backbone");
	var Parse = require("parse");

	var UserModel = Backbone.Model.extend({

		constructorName: "UserModel",
		idUser : "",
		idUserPostedArticle : "",
		
		

		setIdPosted: function(id) { 
			idUserPostedArticle = id;
		},

		registrazione : function() {
			var self = this;

			var user = new Parse.User();
			user.set("nome", document.formregistrazione.nome.value);
			user.set("cognome", document.formregistrazione.cognome.value);
			user.set("telefono", document.formregistrazione.tel.value);
			
			user.set("username", document.formregistrazione.username.value);
			user.set("passwd", document.formregistrazione.password.value);
			user.set("password", document.formregistrazione.password.value);
			user.set("email", document.formregistrazione.email.value);
			user.signUp(null, {
				success : function(user) {
					currentuser = user;
					currentid = user.id;
					
					 navigator.notification.alert(
		        		     'Registrazione effettuata con successo. ',  // message
		        		     function(){ },         // callback
		        		     'Benvenuto in ioRegalo',            // title
		        		     'Ok'                  // buttonName
		        		 );
					 self.setLocalStorage(user.id);
					 self.trigger("registrato");
				},
				error : function(user, error) {
					// Show the error message somewhere and let the user try
					// again.
					alert("Error: " + error.code + " " + error.message);
				}
			});
		},

		saveData : function (){

	        var self = this;
			 var user = Parse.User.current();
	        if((document.editprofile.nome.value)==""){
				user.set("nome", document.editprofile.nome.placeholder);
				}
			else{
			 	user.set("nome",document.editprofile.nome.value);
			}
			if((document.editprofile.cognome.value)==""){
				user.set("cognome", document.editprofile.cognome.placeholder);
				}
			else{
			 	user.set("cognome", document.editprofile.cognome.value);
			}
			if((document.editprofile.tel.value)==""){
				user.set("telefono", document.editprofile.tel.placeholder);
				}
			else{
			 	user.set("telefono", document.editprofile.tel.value);
			}
			
			if((document.editprofile.password.value)==""){
				user.set("passwd", document.editprofile.password.placeholder);
				}
			else{
			 	user.set("passwd", document.editprofile.password.value);
			}
			if((document.editprofile.email.value)==""){
				user.set("email", document.editprofile.email.placeholder);
				}
			else{
			 	user.set("email", document.editprofile.email.value);
			}
			user.save(null, {
                      success : function(){
                       		alert("Evvai! L'aggiornamento del tuo account è avvenuto con successo! :)");
                       		self.trigger("editok");
                      },	
                      error:function(error){
                          alert("Error: " + error.code + " " + error.message);
                          alert("Query fallita");
                      }
                  });

   		},
    
		getProfilo : function (){
			var self = this;
			 var currentUser = Parse.User.current();
			 var currentUser1=  $.parseJSON(JSON.stringify(currentUser));
			
			  var query = new Parse.Query(Parse.User);
			query.equalTo("objectId", localStorage.getItem('id'));
			 
			  query.find({
					success : function(results) {
						for (var i = 0; i < results.length; i++) {
						var result = $.parseJSON(JSON.stringify(results[i]));
					  
					    self.trigger("profilo",result );
						
						}				
					},
					
					error :function(err){
						alert("error"+ err.code + err.message);
					}
					});
			/*var user={};
			user.nome=localStorage.getItem('nome');
	        user.cognome=localStorage.getItem('cognome');
	        user.username=localStorage.getItem('username');
	        user.email=localStorage.getItem('email');
	        user.imgsmall=localStorage.getItem('urlImgSmall');
	        user.imglarge=localStorage.getItem('urlImgLarge');
	        return user; 
	        */
		},
		getUserPrenotati:function(object){
		var arrayResult = [];	
		var self=this;
        var User = Parse.Object.extend("User");
        for (var i = 0; i < object.length; i++) {
                  var query = new Parse.Query(Parse.User);
                  query.equalTo("objectId", object[i].idUser.objectId);
                  query.find({
                    success: function(results) {  
                      var result= $.parseJSON(JSON.stringify(results));
                      self.trigger("ListUserTrattativa", result);
                    },
                    error: function(error) {
                      alert("Error: " + error.code + " " + error.message);
                      alert("Query fallita");
                    }
                  });
                  
                }
		},

		userAnnuncio: function(){
		var self=this;
        var User = Parse.Object.extend("User");
        var query = new Parse.Query(Parse.User);
            query.equalTo("objectId", idUserPostedArticle);
            query.find({
                success:function(results){
                    var result= $.parseJSON(JSON.stringify(results));
                    self.trigger("userdettaglio", result);  
                },

                error:function(error){
                    alert("Error: " + error.code + " " + error.message);
                    alert("Query fallita");
                }
            });      
        },
		

	    queryLoginIoRegalo: function(){

	        var self = this;

	        Parse.User.logIn(document.formIoRegalo.username.value, document.formIoRegalo.password.value, {

	            success: function(user) {
					Parse.User.become("session-token-here").then(
					function(user) {
						
					console.log(user.nome);
					}, function(error) {
						
					});
	                self.setLocalStorage(user.id);	                
					
	            },
	            error: function(user, error){	            
	            	console.log(error);
	                self.trigger("erroreLogin");

	            }
	        });
	      
	      

   		},

   		setLocalStorage: function(userid){
        	var self = this;
			var currentUser = Parse.User.current();
			var currentUser1=  $.parseJSON(JSON.stringify(currentUser));
			var query = new Parse.Query(Parse.User);
			query.equalTo("objectId", currentUser1.objectId);
			
			query.find({
					success : function(results) {
						for (var i = 0; i < results.length; i++) {
						var result = $.parseJSON(JSON.stringify(results[i]));
						}
						//resetto il localStorage creato da facebook
				        localStorage.clear();
				        // inserisco i dati nel localStorage
				        localStorage.setItem('id',userid);
				        localStorage.setItem('nome', result.nome);
				        localStorage.setItem('cognome', result.cognome);
				        localStorage.setItem('username', result.username);
				        localStorage.setItem('email', result.email);
				        localStorage.setItem('urlImgSmall', result.imgProfiloSmall);
				        localStorage.setItem('urlImgLarge', result.imgProfiloLarge);
				        localStorage.setItem('login','true');
					  	self.trigger("loggato");						
										
					},
					
					error :function(err){
						alert("error"+ err.code + err.message);
					}
					});
	        

	    },

	    registration: function(user){
        
	        var self = this;

	        user.signUp(null, {
	            success: function(user) {

	                self.setLocalStorage(user);
	                self.trigger("registrato");

	            },
	            error: function(user, error) {
	             	// Show the error message somewhere and let the user try again.
	            	self.trigger("erroreUser", error);
	            	
	            }
	        });
	    
	    },


		fbLogin: function() {

			var self = this;

			openFB.init('445088995593662'); // Defaults to sessionStorage for storing the Facebook token
		      
		    openFB.login('email', function() {
		            
		        openFB.api({ path: '/me',
		                  
			    	success: function(data) {
			          
						//creo l'utente
						var user = new Parse.User();
						user.set("username", data.name);
						user.set("password", 'facebook');
						user.set("email", data.email);
						user.set("nome", data.first_name);
						user.set("cognome", data.last_name);
						user.set("imgProfiloSmall", 'http://graph.facebook.com/' + data.id + '/picture?type=small');
						user.set("imgProfiloLarge", 'http://graph.facebook.com/' + data.id + '/picture?type=large');

						self.loginParse(user,true);

				    },
				    error: function(error) {

				    	self.trigger("erroreUser", error);
			          
				        alert('Facebook getInfo failed: ' + error.error_description);                

            	  	}
		        });

		    },
		        
		    function(error) {

		        alert('Facebook login failed: ' + error.error_description);
		        
		    });

		},	


		loginParse: function(user,facebook){

	        var self = this;
	        //salvo il valore di user altrimenti viene sovrascritto
	        var utente = user;
	        
	        Parse.User.logIn(user.get("username"), user.get("password"), {

	            success: function(user) {
	                //l'utente esiste,non và registrato
	                self.setLocalStorage(utente);
	                self.trigger("registrato");

	            },
	            error: function(user, error){
	                // se provengo da facebook registro l'utente altrimenti se provengo da ioRegalo faccio 
	                // ricomparire la form con gli errori
	                if(facebook){
	                     //se l'utente non è registrato lo registro
	                    self.registration(utente);
	                } else {
	                    
	                    self.trigger("showMessage");

	                }               

	            }
	        });

	    },


	    recuperaDati: function(){

	        var self = this;
	        var email = document.formIoRegalo.email.value;
	        var User = Parse.Object.extend("User");
	        var query = new Parse.Query(User);
	        query.equalTo("email", email);

	        query.find({
	            success: function(results) {

	                if(results.length == 1){
	                    //se l'email è presente sul db mando una email con il recupero password
	                    self.trigger("successRecupero");

	                } else {

	                	self.trigger("errorRecupero");
	                                        
	                }

	            },
	            error: function(error) {

	               self.trigger("errorQuery");
	          
	            }
	        });
	            
	    },
	    
	    inviaEmail: function(email){

	        var self = this;
	        //eseguo la query che mi prende i la password dell'email richiesta
	        var query = new Parse.Query("User");
	        query.equalTo("email", email);
	        query.find({
	            success: function(results) {
	                var passwd = results[0].get('passwd');
	                var oggetto = "ioRegalo info recupero password"; 
	                var messaggio = "La password da lei richiesta per l'accesso all'app ioRegalo è: " + passwd; 
	                
	                // invio con jquery la mail di recupero
	                $.ajax({
	                    type: "POST",
	                    url: "https://mandrillapp.com/api/1.0/messages/send.json",
	                    data: {
	                        "key": "VUwg1nd-9ECp2iIqe1RG8w",
	                        "message": {
	                            "from_email": "info@ioRegalo.com",
	                            "to": [
	                                {
	                                    "email": "greedydevil@katamail.com",
	                                    "name": "nome",
	                                    "type": "to"
	                                }
	                            ],
	                        "autotext": "true",
	                        "subject": "this.oggetto",
	                        "html": "this.messaggio"
	                        }
	                    }
	                }).done(function(response) {
	                                        
	                    // se è un successo nel code passo 1 cosi carico l'immagine di successo,altrimenti 0 per quella d'errore
	                    self.trigger("successRecupero");

	                });

	            },
	            error: function(error) {

	                self.hideSpinner();

	                var message = "▼ Query fallita!";
	                var classe = "alert-danger";

	                var context = {
	                    message: message,
	                    class: classe
	                }; 

	                $(self.el).html(self.template(context));
	                
	            }
	        });

	    },

	 });   

 return UserModel;
});
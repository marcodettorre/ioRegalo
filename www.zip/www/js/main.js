// here we put the paths to all the libraries and framework we will use
require.config({
  paths: {
    jquery: '../lib/jquery/jquery', // ../lib/zepto/zepto, 
    underscore: '../lib/underscore/underscore',
    backbone: "../lib/backbone/backbone",
    text: '../lib/require/text',
    async: '../lib/require/async',
    handlebars: '../lib/handlebars/handlebars',
    templates: '../templates',
    leaflet: '../lib/leaflet/leaflet',
    spin: '../lib/spin/spin.min',
    utils: '../lib/utils/utils',
    autocomplete: '../lib/autocomplete/jquery.autocomplete',
    parse: '../lib/parse/parse-1.2.18-min',
    openFB: '../lib/facebook/openfb',
    bootstrap: "../lib/bootstrap/js/bootstrap",
    bootstrap_file: "../lib/bootstrap/js/bootstrap.file-input",
    jquery_modal: "../lib/jquery/jquery.modal"

  },
  shim: {
    'autocomplete' : {
      deps: ['jquery'],
      exports: 'autocomplete'
    },
    'jquery': {
      exports: '$'
    },
    'underscore': {
      exports: '_'
    },
    'handlebars': {
      exports: 'Handlebars'
    },
    'leaflet': {
      exports: 'L'
    },
    'parse': {
      deps: ['jquery', 'underscore'],
      exports: 'Parse'
    },
    'bootstrap' : {
      deps:'jquery'
    },
    'bootstrap_file' : {
      deps: 'jquery'
    }
  }
});

// We launch the App
require(['underscore', 'backbone', 'utils', 'parse'], function(_, Backbone, Utils, Parse) {
  require(['router'], function(AppRouter) {
    document.addEventListener("deviceready", run, false);
    function run() {
        // Here we precompile ALL the templates so that the app will be much quickier when switching views
        // see utils.js
        Utils.loadTemplates().once("templatesLoaded", function() {
        //Lanch parse inizialization
        Parse.initialize("tIm9aCiU6eOkOVHd27JlYX0DZlvYZE3T1qdP2buP", "wVnkTdqP597ZYazqjugkOOUJ41T9ZbyUHPWulUQF");
        // launch the router
        var router = new AppRouter();
        Backbone.history.start();
      });
    }
    
  });
});

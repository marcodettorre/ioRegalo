//     Utils.js 0.0.1

//     (c) 2013-2014 Ivano Malavolta
//     Utils may be freely distributed under the MIT license.
//     http://www.ivanomalavolta.com

//// TEMPLATES
//  The structure of this module is the following:
//  - key: the name of the template as it must be referenced by the Backbone view
//  - value: the path of the html file containing the HTML fragment of the template
define({
	login: "templates/login.html",
	loginIoRegalo: "templates/loginIoRegalo.html",
	recuperaDati: "templates/recuperaDati.html",
    structure: "templates/structure.html",
    structureLogin: "templates/structureLogin.html",
    map: "templates/map.html",
    myview: "templates/myview.html",
    homepage: "templates/homePage.html",
    rowhomepage: "templates/rowHomePage.html",    
    paginaricercamappa : "templates/paginaricercamappa.html",
    dettagliannuncio : "templates/dettagliannuncio.html",
    inserisciannuncio : "templates/inserisciAnnuncio.html",
    profilo : "templates/profilo.html",
    edit : "templates/edit.html",
    registrazione : "templates/registrazione.html",
    addposition : "templates/addposition.html",
    trattativa : "templates/trattativa.html",
    prenotazioni : "templates/prenotazioni.html",
    rowtrattativa : "templates/rowTrattativa.html",
    dettagliotrattativa: "templates/dettagliotrattativa.html",
    rowUserTrattativa: "templates/rowUserTrattativa.html"
});